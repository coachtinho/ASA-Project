#include <stdio.h>
#include <stdlib.h>

#define max(A, B) A > B ? A : B
#define min(A, B) A < B ? A : B

enum {
    TRUE = 1,
    FALSE = 0
};

typedef short int bool_t;

/* =============================================================================
 * Graph
 * =============================================================================
 */

typedef struct AdjListNode {
    unsigned long vertex;
    struct AdjListNode *next;
    bool_t visited;
    unsigned long d;
    unsigned long low;
    unsigned long parent;
    bool_t ap;
} AdjListNode;

typedef struct Graph {
    unsigned long numVertices;
    unsigned long articulationPoints;
    AdjListNode **adjLists;
} Graph;

AdjListNode* createNode(unsigned long n) {

    AdjListNode* newNode = (AdjListNode*) malloc(sizeof(AdjListNode));

    newNode->vertex = n;
    newNode->next = NULL;

    return newNode;
}

Graph* createGraph(unsigned long n) {

    Graph *graph = (Graph*) malloc(sizeof(Graph));
    unsigned long i;

    graph->numVertices = n;
    graph->adjLists = (AdjListNode**) malloc(sizeof(AdjListNode*) * n);
    graph->articulationPoints = 0;

    for (i = 0; i < n; i++) {
        graph->adjLists[i] = createNode(i + 1);
    }

    return graph;
}

Graph* addEdge(Graph* graph, unsigned long v1, unsigned long v2) {

    AdjListNode* newNode1 = createNode(v1);
    AdjListNode* newNode2 = createNode(v2);
    AdjListNode* current;

    /* Adds edge to first vertex */
    current = graph->adjLists[v1 - 1];
    while (current->next != NULL) {
        current = current->next;
    }
    current->next = newNode2;

    /* Adds edge to second vertex */
    current = graph->adjLists[v2 - 1];
    while (current->next != NULL) {
        current = current->next;
    }
    current->next = newNode1;

    return graph;
}

void printGraph(Graph *graph) {

    unsigned long i, n = graph->numVertices;
    AdjListNode* current;

    for (i = 0; i < n; i++) {
        current = graph->adjLists[i];
        printf("%lu", current->vertex);
        while (current->next != NULL) {
            printf("->%lu", current->next->vertex);
            current = current->next;
        }
        printf("\n");
    }

}

void freeList(AdjListNode *node) {

    AdjListNode *current;

    if (node != NULL)
        while (node->next != NULL) {
            current = node->next;
            node->next = current->next;
            free(current);
        }

    free(node);
}

void freeGraph(Graph *graph) {

    unsigned long i, n = graph->numVertices;

    for (i = 0; i < n; i++)
        freeList(graph->adjLists[i]);

    free(graph->adjLists);

    free(graph);
}

/* =============================================================================
 * DFS
 * Ignores articulation points and returns size of biggest sub-network
 * =============================================================================
 */

unsigned long DFS_visit(Graph *graph, AdjListNode *node) {

    AdjListNode *current;
    unsigned long netSize = 0;

    node->visited = TRUE;

    /*Visits all adjacent unvisited nodes*/
    for (current = node->next; current != NULL; current = current->next) {
        AdjListNode *currentNode = graph->adjLists[current->vertex - 1];

        if (currentNode->visited == FALSE && currentNode->ap == FALSE)
            netSize = DFS_visit(graph, currentNode);
    }

    return netSize + 1;
}

unsigned long DFS(Graph *graph) {

    unsigned long i, n = graph->numVertices, netSize = 0, maxNetSize = 0;

    /*Reset all vertices to unvisited*/
    for (i = 0; i < n; i++)
        graph->adjLists[i]->visited = FALSE;

    /*Visits all unvisited adjacent nodes*/
    for (i = 0; i < n; i++)
        if (graph->adjLists[i]->visited == FALSE && graph->adjLists[i]->ap == FALSE) {
            netSize = DFS_visit(graph, graph->adjLists[i]);
            maxNetSize = max(netSize, maxNetSize);
        }

    return maxNetSize;
}

/* =============================================================================
 * Tarjan
 * Counts articulation points, sub-netowrks and each sub-network's maximum index
 * =============================================================================
 */

unsigned long tarjanVisit(Graph *graph, AdjListNode *node) {

    AdjListNode *current;
    static unsigned long time;
    unsigned long children = 0, currentIndex = 0, maxIndex = node->vertex;

    node->visited = TRUE;
    node->d = ++time;
    node->low = node->d;

    /*Visits all unvisited adjacent nodes*/
    for (current = node->next; current != NULL; current = current->next) {
        AdjListNode *currentNode = graph->adjLists[current->vertex - 1];

        if (currentNode->visited == FALSE) {
            children++;
            currentNode->parent = node->vertex;

            currentIndex = tarjanVisit(graph, currentNode);
            maxIndex = max(maxIndex, currentIndex);

            /*Updates node's low value*/
            node->low = min(node->low, currentNode->low);

            /*Checks if node is articulation point*/
            if ((node->parent == 0 && children > 1) ||
                (node->parent != 0 && currentNode->low >= node->d)) {
                if (node->ap == FALSE) {
                    graph->articulationPoints++;
                    node->ap = TRUE;
                }
            }

        /*Updates node's low value*/
        } else if (currentNode->vertex != node->parent)
            node->low = min(node->low, currentNode->d);
    }

    return maxIndex;
}

unsigned long tarjan(Graph *graph, unsigned long maxIndexes[]) {

    unsigned long i, maxIndex, n = graph->numVertices, subNetCount = 0;

    /*Resets all nodes*/
    for (i = 0; i < n; i++) {
        graph->adjLists[i]->visited = FALSE;
        graph->adjLists[i]->parent = 0;
        graph->adjLists[i]->ap = FALSE;
    }

    /*Visits all unvisited nodes*/
    for (i = 0; i < n; i++)
        if (graph->adjLists[i]->visited == FALSE) {
            maxIndex = tarjanVisit(graph, graph->adjLists[i]);
            maxIndexes[subNetCount++] = maxIndex;
        }

    return subNetCount;
}

/* =============================================================================
 * Main
 * =============================================================================
 */

int main(int argc, char const *argv[]) {

    Graph* graph;
    unsigned long n, e;
    unsigned long v1, v2;
    unsigned long i;
    unsigned long subNetworks;

    /* Gets number of vertices and edges from stdin */
    scanf("%lu\n%lu", &n, &e);

    /* Setups graph */
    unsigned long maxIndexes[n];
    graph = createGraph(n);
    for (i = 0; i < e; i++) {
        scanf("\n%lu %lu", &v1, &v2);
        addEdge(graph, v1, v2);
    }

    printGraph(graph);

    subNetworks = tarjan(graph, maxIndexes);

    printf("%lu\n", subNetworks);
    for (i = 0; i < subNetworks; i++)
        printf("%lu ", maxIndexes[i]);

    printf("\n%lu\n%lu\n", graph->articulationPoints, DFS(graph));

    freeGraph(graph);

    return 0;
}
